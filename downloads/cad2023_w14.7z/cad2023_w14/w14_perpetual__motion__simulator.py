# 以下的 zmq 程式庫已經過修改, 可以在 IPv4 與 IPv6 環境下使用
# 針對 CoppeliaSim 的 zmq 延伸程式, Python 需要安裝 cbor 與 pyzmq 等兩個模組
# pip install cbor pyzmq
from zmqRemoteApi_IPv6 import RemoteAPIClient
# 由於在 zmq 程式執行時, 希望讓使用者可以透過鍵盤 (或其他電子電機訊號) 指令控制遠端的機電模擬場景
# Python 程式環境還需要安裝 keyboard 模組, pip install keyboard
import keyboard

# 利用以下程式碼連接 CoppeliaSim remote API server
#第一個輸入變數若為 localhost 則只能控制與程式同在的場景
# 但若第一輸入變數為可連外的 IPv4 或 IPv6 address, 則可用來控制遠端電腦上的模擬場景
# 23000 為 CoppeliaSim 使用 ZMQ remote API 連線控制時內定的網路埠號
# client 與 server 的防火牆或代理主機必須讓此埠號的封包 (socket) 通過
client = RemoteAPIClient('localhost', 23000)

# 利用 getObject 取得場景中的 "sim" 物件參考對應值
sim = client.getObject('sim')

# 利用 sim 物件的 startSimulation() 方法啟動場景模擬
sim.startSimulation()

# 利用 getObject 取得 'marble' and 'sensor'  物件的參考對應值
marble = sim.getObject('./marble')
sensor = sim.getObject('./sensor')

# 透過變數屬性設定方法將 marble 設為 non-static, 意即具有 dynamic 特性
sim.setObjectInt32Param(marble, sim.shapeintparam_static, 0)

# 定義 marble, 平台孔洞與軌道末端 的 initial positions
initial_position = [-0.825, -0.2, 1.625]
end_of_rail_position = [0.675, -0.225, 1.1]

# 設定 marble 的起始位置
sim.setObjectPosition(marble, -1, initial_position)

# PID 控制參數
kp = 5.0   # Proportional gain 控制訊號的比例增益
ki = 0.1   # Integral gain 控制訊號的積分增益
kd = 2.0   # Derivative gain 控制訊號的微分增益

# 設定 PID 控制的起始誤差值
error_integral = 0.0
last_error = 0.0

# 設定最大的 marble 重置位置誤差值 (若誤差大於 0.5, 則將 marble 設回起始位置)
max_reset_error = 0.5

# 主模擬程序
while True:
    if keyboard.is_pressed('q'):
        # 模擬執行期間, 將滑鼠停在場景, 鍵盤按下 q 可以終止模擬
        break

    # 取得 proximity sensor 的回傳變數值
    r, dist, pt, obj, normal = sim.handleProximitySensor(sensor)

    # 當鋼球碰觸感測器時
    if r > 0:
        # 對鋼球質心施以一個向量力
        sim.addForceAndTorque(marble, [-300, 0, -700], [0, 0, 0])

    # 利用 getObjectPosition() 取得鋼球的座標值
    current_position = sim.getObjectPosition(marble, -1)

    # 查驗鋼球是否抵達軌道終點
    if current_position[0] > end_of_rail_position[0]:
        # 照理應該要讓鋼球離開軌道後, 以拋物線飛起並落下時
        # 取得通過平台圓孔平面時的 (x, y) 座標後, 再計算施力後的落點誤差
        error = initial_position[0] - current_position[0]

        # Update the integral of the error
        error_integral += error

        # Calculate the derivative of the error
        error_derivative = error - last_error

        # Calculate the control output (PID) for x and z directions
        control_output_x = kp * error + ki * error_integral + kd * error_derivative
        control_output_z = -kp * current_position[2]  # Adjust kp for the z-direction as needed

        # Print the control forces and PID parameters
        print(f"Control Force X: {control_output_x}, Control Force Z: {control_output_z}")
        print(f"PID Parameters: kp={kp}, ki={ki}, kd={kd}")

        # Apply force to propel the marble back to the initial position
        sim.addForceAndTorque(marble, [control_output_x, 0, control_output_z], [0, 0, 0])

        # Print the coordinates as the marble drops
        print(f"X: {current_position[0]}, Y: {current_position[1]}, Z: {current_position[2]}")

        # Check if the error exceeds the maximum for reset
        if abs(error) > max_reset_error:
            # Reset the marble position to the initial position
            sim.setObjectPosition(marble, -1, initial_position)
            # Reset PID variables
            error_integral = 0.0
            last_error = 0.0
            # Print a message indicating the marble is reset
            print("Reset")
        else:
            # Print a message indicating the marble is not reset
            print("Not reset")

        # Update the last error
        last_error = error

# Stop the simulation
sim.stopSimulation()
