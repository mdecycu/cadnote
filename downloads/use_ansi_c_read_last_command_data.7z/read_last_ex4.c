#include <stdio.h>
#include <string.h>

int main() {
    // Open the CAD file for reading
    FILE* cad_file = fopen("cad2023_2b_w8.txt", "r");
    if (cad_file == NULL) {
        perror("Error opening CAD file");
        return 1;
    }

    char line[100]; // Assuming a maximum line length of 100 characters

    char unique_users[100][20]; // Assuming a maximum of 100 unique users with a length of 20 characters each
    int unique_user_count = 0;

    // Read the CAD file line by line
    while (fgets(line, sizeof(line), cad_file)) {
        char* token = strtok(line, " "); // Split the line by space
        if (token != NULL && strstr(token, "cad") == token) {
            // Extract the student number (skip "cad")
            char student_number[20]; // Assuming a maximum length of 20 characters for a student number
            strcpy(student_number, token + 3); // Skip "cad"
            
            // Check for duplicates and add to the unique_users array
            int is_duplicate = 0;
            for (int i = 0; i < unique_user_count; i++) {
                if (strcmp(unique_users[i], student_number) == 0) {
                    is_duplicate = 1;
                    break;
                }
            }

            if (!is_duplicate) {
                strcpy(unique_users[unique_user_count], student_number);
                unique_user_count++;
            }
        }
    }

    // Reverse the order of the unique student numbers
    for (int i = 0; i < unique_user_count / 2; i++) {
        char temp[20];
        strcpy(temp, unique_users[i]);
        strcpy(unique_users[i], unique_users[unique_user_count - 1 - i]);
        strcpy(unique_users[unique_user_count - 1 - i], temp);
    }

    // Print the unique student numbers in reverse order
    for (int i = 0; i < unique_user_count; i++) {
        printf("%s\n", unique_users[i]);
    }

    // Close the CAD file
    fclose(cad_file);

    return 0;
}
